package com.example.hp.broadcast;


import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{

    public static final int REQUEST_ID_PERMISSION = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(checkAndRequestPermissions())
        {
            Log.d ("TAG", "Permissions are granted");
        }


    }
    private  boolean checkAndRequestPermissions()
    {


        if (Build.VERSION.SDK_INT >= Build.VERSION.SDK_INT)
        {

            int PermissionSMSRecive = ContextCompat.checkSelfPermission(this,Manifest.permission.RECEIVE_SMS);
            int ReadSms = ContextCompat.checkSelfPermission(this,Manifest.permission.READ_SMS);


            List<String> listPermissionsNeeded = new ArrayList<>();



            if(PermissionSMSRecive != PackageManager.PERMISSION_GRANTED)
            {
                listPermissionsNeeded.add(Manifest.permission.RECEIVE_SMS);
            }

            if(ReadSms != PackageManager.PERMISSION_GRANTED)
            {
                listPermissionsNeeded.add(Manifest.permission.CALL_PHONE);
            }



            if (!listPermissionsNeeded.isEmpty())
            {
                ActivityCompat.requestPermissions(this,
                        listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]),
                        REQUEST_ID_PERMISSION);
                return false;
            }


            return true;
        }

        else
            return true;
    }
}

