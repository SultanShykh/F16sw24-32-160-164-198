package com.example.hp.broadcast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;

public class SmsRead extends BroadcastReceiver
{

    final SmsManager sms = SmsManager.getDefault();

    public void onReceive(Context context, Intent intent)
    {

        // Retrieves a map of extended data from the intent.
        Bundle bundle = intent.getExtras();
        if (bundle != null)
        {
            Object [] pdus = (Object[]) bundle.get("pdus");
            String Sms;
            SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdus[0]);
            //sms variable storing the actual message in string format

            Sms = sms.getDisplayMessageBody().toString();

            String search = "hello";

            if(Sms.toLowerCase().contains(search))
            {
                Toast.makeText(context.getApplicationContext(),Sms,Toast.LENGTH_SHORT).show();
            }

        }

    }// close the on Receive Methord



}// Close the Main Class
